<?php
return [
    'db_name' => 'kursovaya',
    'db_host' => '127.0.0.1',
    'db_user' => 'root',
    'db_pass' => 'root',
    
]; ?>
