<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    require("do_Unloading.php");
    ?>
    <form action="do_Unloading.php" method="post">
        <button type="submit" class="btn btn-success mt-3 w-25">Выгрузить</button>
    </form>
    <?echo "<table class='table' style='border-spacing: 0px 0px; font-size: 18px;'>" .  "<thead class='thead-table'><tr><th scope='col' style='width: 200px; text-align: center;border-bottom: 2px solid black;'>" . "<h3>Номер</h3>" .
    "</th><th scope='col' style='width: 200px; text-align: center; border-bottom: 2px solid black;'>" . "<h3>Профессия</h3>" .
    "</th><th scope='col' style='width: 200px; text-align: center; border-bottom: 2px solid black;'>" . "<h3>Кол-во рабочих мест</h3>" .
    "</th><th scope='col' style='width: 200px; text-align: center; border-bottom: 2px solid black;'>" . "<h3>Зарплата</h3>" .
    "</th><th scope='col' style='width: 200px; text-align: center; border-bottom: 2px solid black;'>" . "<h3>Регион города</h3>" .
    "</th><th scope='col' style='width: 200px; text-align: center; border-bottom: 2px solid black;'>" . "<h3>Ограничения по полу</h3>" .
    "</th><th scope='col' style='width: 200px; text-align: center; border-bottom: 2px solid black;'>" . "<h3>Возраст</h3>" .
    "</th><th scope='col' style='width: 200px; text-align: center; border-bottom: 2px solid black;'>" . "<h3>Образование</h3>" . 
    "</th></tr></thead>" ;
foreach($result as $row){
    echo 
    "<tbody><tr style=''><th scope='row' style='border-bottom: 2px solid #f2f4f5; text-align: center; height: 50px;'>" .htmlspecialchars($row['id']).
    "</th><td style='border-bottom: 2px solid #f2f4f5;text-align: center;'>" . htmlspecialchars($row['profession']) .
    "</td><td style='border-bottom: 2px solid #f2f4f5;text-align: center;'>" . htmlspecialchars($row['countPlace']) .
    "</td><td style='border-bottom: 2px solid #f2f4f5;text-align: center;'>" . htmlspecialchars($row['salary']) . 
    "</td><td style='border-bottom: 2px solid #f2f4f5;text-align: center;'>" . htmlspecialchars($row['townRegion']) . 
    "</td><td style='border-bottom: 2px solid #f2f4f5;text-align: center;'>" . htmlspecialchars($row['restrictSex']) . 
    "</td><td style='border-bottom: 2px solid #f2f4f5;text-align: center;'>" . htmlspecialchars($row['age']) . 
    "</td><td style='border-bottom: 2px solid #f2f4f5;text-align: center;'>" . htmlspecialchars($row['education']) . 
    "</td></tr>
    </tbody>";
}
echo "</table>";
?>
</body>
</html>