<?php
require('boot.php');
if (check_auth()) {
    // Получим данные пользователя по сохранённому идентификатору
    $stmt = pdo()->prepare("SELECT * FROM `users` WHERE `id` = :id");
    $stmt->execute(['id' => $_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    $username = $user['username'];
}
$stmt = pdo()->prepare("SELECT * FROM `offers` WHERE `user`= '$username'");

$stmt->execute();


$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

// var_dump($result[1]);
$stmt->setFetchMode(PDO::FETCH_ASSOC);  
// while($row = $stmt->fetchAll()) {  
//     echo $row['id'] . "\n";  
//     echo $row['profession'] . "\n";  
//     echo $row['countPlace'] . "\n";  
// }
// echo "<table >"; // start a table tag in the HTML
// foreach($result as $row){
//     echo 
//     "<tr><td>" . "<h3>Номер</h3>" .
//     "</td><td>" . "<h3>Профессия</h3>" .
//     "</td><td>" . "<h3>Кол-во рабочих мест</h3>" .
//     "</td><td>" . "<h3>Зарплата</h3>" .
//     "</td><td>" . "<h3>Регион города</h3>" .
//     "</td><td>" . "<h3>Ограничения по полу</h3>" .
//     "</td><td>" . "<h3>Возраст</h3>" .
//     "</td><td>" . "<h3>Образование</h3>" .

//     "</td></tr>" .
//     "<tr><td>" . htmlspecialchars($row['id']) . 
//     "</td><td>" . htmlspecialchars($row['profession']) . 
//     "</td><td>" . htmlspecialchars($row['countPlace']) . 
//     "</td><td>" . htmlspecialchars($row['salary']) . 
//     "</td><td>" . htmlspecialchars($row['townRegion']) . 
//     "</td><td>" . htmlspecialchars($row['restrictSex']) . 
//     "</td><td>" . htmlspecialchars($row['age']) . 
//     "</td><td>" . htmlspecialchars($row['education']) . 
//     "</td></tr>";  //$row['index'] the index here is a field name
// }
// echo "</table>";

echo "<table class='table' style='border-spacing: 0px 0px; font-size: 18px;'>" .  "<thead class='thead-table'><tr><th scope='col' style='width: 200px; text-align: center;border-bottom: 2px solid black;'>" . "<h3>Номер</h3>" .
    "</th><th scope='col' style='width: 200px; text-align: center; border-bottom: 2px solid black;'>" . "<h3>Профессия</h3>" .
    "</th><th scope='col' style='width: 200px; text-align: center; border-bottom: 2px solid black;'>" . "<h3>Кол-во рабочих мест</h3>" .
    "</th><th scope='col' style='width: 200px; text-align: center; border-bottom: 2px solid black;'>" . "<h3>Зарплата</h3>" .
    "</th><th scope='col' style='width: 200px; text-align: center; border-bottom: 2px solid black;'>" . "<h3>Регион города</h3>" .
    "</th><th scope='col' style='width: 200px; text-align: center; border-bottom: 2px solid black;'>" . "<h3>Ограничения по полу</h3>" .
    "</th><th scope='col' style='width: 200px; text-align: center; border-bottom: 2px solid black;'>" . "<h3>Возраст</h3>" .
    "</th><th scope='col' style='width: 200px; text-align: center; border-bottom: 2px solid black;'>" . "<h3>Образование</h3>" . 
    "</th></tr></thead>" ;
foreach($result as $row){
    echo 
    "<tbody><tr style=''><th scope='row' style='border-bottom: 2px solid #f2f4f5; text-align: center; height: 50px;'>" .htmlspecialchars($row['id']).
    "</th><td style='border-bottom: 2px solid #f2f4f5;text-align: center;'>" . htmlspecialchars($row['profession']) .
    "</td><td style='border-bottom: 2px solid #f2f4f5;text-align: center;'>" . htmlspecialchars($row['countPlace']) .
    "</td><td style='border-bottom: 2px solid #f2f4f5;text-align: center;'>" . htmlspecialchars($row['salary']) . 
    "</td><td style='border-bottom: 2px solid #f2f4f5;text-align: center;'>" . htmlspecialchars($row['townRegion']) . 
    "</td><td style='border-bottom: 2px solid #f2f4f5;text-align: center;'>" . htmlspecialchars($row['restrictSex']) . 
    "</td><td style='border-bottom: 2px solid #f2f4f5;text-align: center;'>" . htmlspecialchars($row['age']) . 
    "</td><td style='border-bottom: 2px solid #f2f4f5;text-align: center;'>" . htmlspecialchars($row['education']) . 
    "</td></tr>
    </tbody>";
}
echo "</table>";
// if (is_array($result)) {
//     while ($row = $stmt->fetchAll(PDO::FETCH_ASSOC)) {
//         $id = $row['id'];
//         $profession = $row['profession'];
//         $countPlace = $row['countPlace'];
//         $salary = $row['salary'];
//         $townRegion = $row['townRegion'];
//         $restrictSex = $row['restrictSex'];
//         $age = $row['age'];
//         $education = $row['education'];
//         echo "<p>$id - $profession - $countPlace - $salary - $townRegion - $restrictSex - $age - $education</p>";
//     }
// }

 // foreach ($result as $row) {
    //     $firstName = $row["firstName"];
    //     $titleShip = $row["titleShip"];
    //     // $port = $row["Port_ship"];
    //     // var_dump($firstName);
    //     // echo $port.', ';
    // }
 