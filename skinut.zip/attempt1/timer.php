<?php


    $datetime1 = new DateTime(date("Ymd")); //Получаем текущую дату
    $datetime2 = new DateTime('20221016'); //Дата акции
    $date1 = new DateTime();
    
    $datetime3 = new DateTime(date("H:i:s"));//Получаем текущее время
    $datetime4 = new DateTime('23:59:59');//Время, до которого действует акция

    $interval1 = $datetime1->diff($datetime2);// Считаем разницу для года, месяца и дня
    $interval2 = $datetime3->diff($datetime4); // И считаем разницу для времени
    // Здесь должна быть проверка, не отрицательный ли интервал, но это можно сделать через 10 месяцев, поэтому отложим пока
    
    echo $interval1->format('До конца акции осталось: %m мес. %d д.'); // отправляем результаты обратно
    echo $interval2->format(' %h ч. %i мин. %s сек.');

    $reg_date = Date('h:i:s'); 
    echo $reg_date;// Дата регистрации
	// $premium_date = date("d.m.Y H:i:s", strtotime("+1 days", strtotime($reg_date)));
	
	// echo "Дата окончания премиум аккаунта: ".$premium_date

        // $sql = "UPDATE `ships` SET Coordinates = $_firstShipCoord[]";
        // var_dump($_firstShipCoord["_pointOne"]);
?>